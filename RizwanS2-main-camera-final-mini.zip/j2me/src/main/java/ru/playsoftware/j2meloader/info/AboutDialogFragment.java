/*
 * Copyright 2017 Nikita Shakarun
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ru.playsoftware.j2meloader.info;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.text.util.Linkify;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import ru.playsoftware.j2meloader.BuildConfig;
import ru.playsoftware.j2meloader.R;

public class AboutDialogFragment extends DialogFragment {
	@NonNull
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		StringBuilder message = new StringBuilder().append(getText(R.string.jl_version))
				.append(BuildConfig.J2ME_VERSION_NAME)
				.append(getText(R.string.about_discord))
				.append(getText(R.string.about_github))
				.append(getText(R.string.about_4pda))
				.append(getText(R.string.about_xda))
				.append(getText(R.string.about_emugen_wiki))
				.append(getText(R.string.about_crowdin))
				.append(getText(R.string.about_copyright));
		TextView tv = new TextView(getActivity());
		tv.setText(Html.fromHtml(message.toString()));
		tv.setTextSize(16);
		tv.setMovementMethod(new ScrollingMovementMethod());
		Linkify.addLinks(tv, Linkify.ALL);
		float density = getResources().getDisplayMetrics().density;
		int paddingHorizontal = (int) (density * 20);
		int paddingVertical = (int) (density * 14);
		tv.setPadding(paddingHorizontal, paddingVertical, paddingHorizontal, 0);
		AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
		builder.setTitle(R.string.jl_app_name)
				.setIcon(R.mipmap.jl_ic_launcher)
				.setView(tv)
				.setPositiveButton(R.string.licenses, (dialog, which) -> {
					LicensesDialogFragment licensesDialogFragment = new LicensesDialogFragment();
					licensesDialogFragment.show(getParentFragmentManager(), "licenses");
				})
				.setNeutralButton(R.string.more, (dialog, which) -> {
					InfoDialogFragment infoDialogFragment = new InfoDialogFragment();
					infoDialogFragment.show(getParentFragmentManager(), "more");
				});
		return builder.create();
	}
}
